<?php
include 'header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>View Availability & Reserve Equipment</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="main-content">
        <header>
            <h1>View Equipment Availability & Reserve</h1>
        </header>

        <!-- Equipment Availability Section -->
        <section class="equipment-availability">
            <h2>Available Equipment</h2>
            <div class="catalogue-container">
                <div class="card">
                    <h3>Camera</h3>
                    <p>Available: 5</p>
                    <button onclick="showReservationForm('Camera')">Reserve</button>
                </div>
                <div class="card">
                    <h3>Laptop</h3>
                    <p>Available: 2</p>
                    <button onclick="showReservationForm('Laptop')">Reserve</button>
                </div>
                <div class="card">
                    <h3>Projector</h3>
                    <p>Available: 3</p>
                    <button onclick="showReservationForm('Projector')">Reserve</button>
                </div>
            </div>
        </section>

        <!-- Reservation Form Section (Initially Hidden) -->
        <section class="reserve-equipment" id="reservation-form" style="display:none;">
            <h2>Reserve Equipment</h2>
            <form action="reserve_process.php" method="post">
                <label for="equipment">Selected Equipment:</label>
                <input type="text" id="selected-equipment" name="equipment" readonly>

                <label for="reservation-date">Reservation Date:</label>
                <input type="date" id="reservation-date" name="reservation_date" required>

                <label for="return-date">Return Date:</label>
                <input type="date" id="return-date" name="return_date" required>

                <button type="submit" class="reserve-btn">Reserve</button>
            </form>
        </section>
    </div>

    <script>
        function showReservationForm(equipment) {
            document.getElementById('reservation-form').style.display = 'block';
            document.getElementById('selected-equipment').value = equipment;
        }
    </script>
</body>
</html>
