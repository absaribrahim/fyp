<?php include 'header.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Dashboard - Design Equipment System</title>
    <!-- Link to Google Fonts and Font Awesome -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <!-- Link to Animate.css for animations -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

    <!-- Main Content Area -->
    <div class="main-content">
        <!-- Welcome Section -->
        <section class="welcome-section animate__animated animate__fadeIn">
            <h1>Welcome to the Design Equipment Booking System</h1>
            <p>Efficiently manage and reserve design equipment with ease.</p>
        </section>

        <!-- Quick Actions Section with Enhanced Cards -->
        <section class="dashboard-overview">
            <h2>Quick Actions</h2>
            <div class="grid-layout">
                <div class="card animate__animated animate__fadeInUp">
                    <h3><i class="fas fa-calendar-alt"></i> Reserve Equipment</h3>
                    <p>Reserve available equipment for your upcoming project.</p>
                    <a href="reserve.php" class="btn">Reserve Now</a>
                </div>
                <div class="card animate__animated animate__fadeInUp animate__delay-1s">
                    <h3><i class="fas fa-check-circle"></i> Check Availability</h3>
                    <p>View current availability of design equipment.</p>
                    <a href="availability.php" class="btn">View Availability</a>
                </div>
                <div class="card animate__animated animate__fadeInUp animate__delay-2s">
                    <h3><i class="fas fa-search"></i> Track Equipment</h3>
                    <p>Track borrowed equipment and manage returns.</p>
                    <a href="track.php" class="btn">Track Equipment</a>
                </div>
            </div>
        </section>
    </div>

    <!-- Footer Section -->
    <footer class="footer">
        <p>&copy; 2024 Design Equipment Booking System | Help | Contact</p>
        <div class="social-icons">
            <a href="#"><i class="fab fa-facebook"></i></a>
            <a href="#"><i class="fab fa-twitter"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
        </div>
    </footer>

    <!-- Initialize AOS Animation Library -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    <script>
        AOS.init();
    </script>
</body>
</html>
