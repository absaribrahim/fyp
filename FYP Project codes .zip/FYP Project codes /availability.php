<?php
include 'header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Equipment Availability</title>
    <link rel="stylesheet" href="styles.css">
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@5.5.0/main.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.5.0/main.min.js"></script>
</head>
<body>
    <div class="container">
        <!-- Sidebar Navigation -->
        <nav class="sidebar">
            <ul>
                <li><a href="index.php"><i class="fas fa-home"></i> Home</a></li>
                <li><a href="reserve.php"><i class="fas fa-calendar-alt"></i> Reserve Equipment</a></li>
                <li><a href="availability.php"><i class="fas fa-check-circle"></i> View Availability</a></li>
                <li><a href="reservations.php"><i class="fas fa-list"></i> My Reservations</a></li>
                <li><a href="track.php"><i class="fas fa-search"></i> Track Equipment</a></li>
            </ul>
        </nav>

        <!-- Main Content -->
        <div class="main-content">
            <section class="availability-section">
                <div class="card">
                    <h2>Equipment Availability Calendar</h2>
                    <div id="calendar"></div>
                </div>
            </section>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var calendarEl = document.getElementById('calendar');
            var calendar = new FullCalendar.Calendar(calendarEl, {
                initialView: 'dayGridMonth',
                events: [
                    {
                        title: 'Camera - Booked',
                        start: '2024-09-10',
                        end: '2024-09-12'
                    },
                    {
                        title: 'Laptop - Booked',
                        start: '2024-09-15',
                        end: '2024-09-17'
                    }
                ]
            });
            calendar.render();
        });
    </script>
</body>
</html>
