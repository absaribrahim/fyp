<?php
include 'header.php';
session_start();

// Handle POST requests for updating reservation status
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['reservation_id']) && isset($_POST['action'])) {
        foreach ($_SESSION['reservations'] as &$reservation) {
            if ($reservation['id'] == $_POST['reservation_id']) {
                $reservation['status'] = $_POST['action'] === 'approve' ? 'Approved' : 'Rejected';
                echo "<div class='alert success'>Reservation status updated!</div>";
                break;
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Reservations Management</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <!-- Sidebar Navigation -->
    <nav class="sidebar">
        <h2>Admin Panel</h2>
        <ul>
            <li><a href="index.php"><i class="fas fa-home"></i> Dashboard</a></li>
            <li><a href="admin_panel.php"><i class="fas fa-tools"></i> Manage Equipment</a></li>
            <li><a href="admin_reservations.php" class="active"><i class="fas fa-list"></i> Manage Reservations</a></li>
            <li><a href="track.php"><i class="fas fa-search"></i> Track Equipment</a></li>
            <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
    </nav>

    <div class="admin-panel-container">
        <h1 class="admin-title">Manage Reservations</h1>

        <section class="admin-section">
            <h2>Approve or Reject Reservations</h2>
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Reservation ID</th>
                        <th>User</th>
                        <th>Equipment</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($_SESSION['reservations'] as $reservation): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($reservation['id']); ?></td>
                            <td><?php echo htmlspecialchars($reservation['user']); ?></td>
                            <td><?php echo htmlspecialchars($reservation['equipment']); ?></td>
                            <td><?php echo htmlspecialchars($reservation['status']); ?></td>
                            <td>
                                <?php if ($reservation['status'] == 'Pending'): ?>
                                    <form action="admin_reservations.php" method="post" class="admin-actions">
                                        <input type="hidden" name="reservation_id" value="<?php echo $reservation['id']; ?>">
                                        <button type="submit" name="action" value="approve" class="btn success">Approve</button>
                                        <button type="submit" name="action" value="reject" class="btn danger">Reject</button>
                                    </form>
                                <?php else: ?>
                                    <?php echo htmlspecialchars($reservation['status']); ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>
    </div>
</body>
</html>
