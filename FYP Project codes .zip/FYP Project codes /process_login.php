<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Placeholder for proper user validation (e.g., from a database)
    if ($username == 'admin' && $password == 'password') {
        $_SESSION['user'] = $username; // Store user information in the session
        header("Location: index.php");  // Redirect to the homepage
        exit();
    } else {
        echo "Invalid username or password.";
    }
}
?>
