<?php
include 'header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Track Equipment</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <!-- Main Content -->
        <div class="main-content">
            <section class="track-equipment-section">
                <div class="card">
                    <h2>Track Equipment Status</h2>
                    <table>
                        <thead>
                            <tr>
                                <th>Equipment</th>
                                <th>Current Status</th>
                                <th>Location</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Camera</td>
                                <td>Available</td>
                                <td>Room 101</td>
                            </tr>
                            <tr>
                                <td>Laptop</td>
                                <td>Booked</td>
                                <td>With John Doe</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </section>
        </div>
    </div>
</body>
</html>
