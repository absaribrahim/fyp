<?php
// Placeholder for checking notifications (this would be connected to a real database)
$notifications = "You have a new reservation request!";

if (!empty($notifications)) {
    echo $notifications;
} else {
    echo ""; // No new notifications
}
?>
