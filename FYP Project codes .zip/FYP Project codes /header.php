<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>

<!-- Main Header -->
<header class="main-header">
    <div class="logo">
        <h2>Dashboard</h2>
    </div>
    <div class="user-info">
        <p>Welcome, <?php echo $_SESSION['user']; ?>!</p>
        <a href="logout.php" class="logout-btn">Logout</a>
    </div>
</header>

<!-- Sidebar Navigation -->
<nav class="sidebar">
    <ul>
        <li><a href="index.php"><i class="fas fa-home"></i> Home</a></li>
        <li><a href="admin_panel.php"><i class="fas fa-tools"></i> Admin Panel</a></li>

        <li><a href="reserve.php"><i class="fas fa-calendar-alt"></i> Reservations</a></li>
       
        <li><a href="reservations.php"><i class="fas fa-list"></i> My Reservations</a></li>
        <li><a href="track.php"><i class="fas fa-search"></i> Track Equipment</a></li>
        <?php if ($_SESSION['role'] === 'admin'): ?>
            <li><a href="admin_panel.php"><i class="fas fa-tools"></i> Admin Panel</a></li>
        <?php endif; ?>
        <li><a href="#"><i class="fas fa-question-circle"></i> Help</a></li>
    </ul>
</nav>

<!-- Inline CSS for Minimalist Design -->
<style>
    /* Main Header Styling */
    .main-header {
        width: 100%;
        background-color: #ffffff; /* White background for minimalist look */
        padding: 15px 20px;
        color: #333; /* Dark text for contrast */
        display: flex;
        justify-content: space-between;
        align-items: center;
        position: fixed;
        top: 0;
        left: 0;
        z-index: 1000;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* Minimal shadow */
    }

    .main-header .logo h2 {
        margin: 0;
        font-family: 'Poppins', sans-serif;
        font-size: 24px;
        color: #444;
    }

    .main-header .user-info {
        display: flex;
        align-items: center;
        gap: 20px;
    }

    .main-header .user-info p {
        margin: 0;
        font-size: 16px;
        color: #555;
    }

    .logout-btn {
        color: white;
        background-color: #e94560;
        padding: 8px 18px;
        border-radius: 50px;
        text-decoration: none;
        font-size: 14px;
        transition: background-color 0.3s ease;
    }

    .logout-btn:hover {
        background-color: #d1304b;
    }

    /* Sidebar Navigation Styling */
    .sidebar {
        width: 250px;
        background-color: #1f1f1f; /* Minimalist black sidebar */
        height: 100vh;
        position: fixed;
        top: 70px; /* Below the header */
        left: 0;
        padding-top: 20px;
        display: flex;
        flex-direction: column;
        align-items: center;
    }

    .sidebar ul {
        list-style-type: none;
        padding: 0;
        width: 100%;
    }

    .sidebar ul li a {
        display: flex;
        align-items: center;
        padding: 12px 20px;
        color: white;
        text-decoration: none;
        font-size: 16px;
        transition: background-color 0.3s ease;
        margin-bottom: 10px;
        border-radius: 6px;
    }

    .sidebar ul li a i {
        margin-right: 10px; /* Space between icon and text */
        font-size: 20px;
    }

    .sidebar ul li a:hover {
        background-color: #333333;
    }

    /* Adjust body content to leave space for the sidebar */
    body {
        padding-top: 70px;
        padding-left: 250px; /* Leave space for the sidebar */
        background-color: #f7f7f7; /* Light background */
        font-family: 'Roboto', sans-serif;
        color: #333;
    }

    /* Responsive Design for Smaller Screens */
    @media (max-width: 768px) {
        .sidebar {
            width: 100%;
            height: auto;
            position: relative;
        }

        body {
            padding-left: 0;
        }
    }
</style>

<!-- Include Font Awesome CDN for Icons -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
