<?php
include 'header.php';
session_start();

// Simulated equipment list (replace with database later)
if (!isset($_SESSION['equipment'])) {
    $_SESSION['equipment'] = [];
}

// Handle POST requests for adding equipment
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['equipment_name']) && isset($_POST['quantity'])) {
        $_SESSION['equipment'][] = [
            'name' => $_POST['equipment_name'],
            'quantity' => $_POST['quantity'],
        ];
        echo "<div class='alert success'>New equipment added successfully!</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Admin Panel</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <!-- Sidebar Navigation -->
    <nav class="sidebar">
        <h2>Admin Panel</h2>
        <ul>
            <li><a href="index.php"><i class="fas fa-home"></i> Dashboard</a></li>
            <li><a href="admin_panel.php" class="active"><i class="fas fa-tools"></i> Manage Equipment</a></li>
            <li><a href="admin_reservations.php"><i class="fas fa-list"></i> Manage Reservations</a></li>
            <li><a href="track.php"><i class="fas fa-search"></i> Track Equipment</a></li>
            <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
    </nav>

    <div class="admin-panel-container">
        <h1 class="admin-title">Manage Equipment</h1>

        <section class="admin-section">
            <h2>Add New Equipment</h2>
            <form action="admin_panel.php" method="post" class="admin-form">
                <div class="form-group">
                    <label for="equipment-name">Equipment Name:</label>
                    <input type="text" id="equipment-name" name="equipment_name" required>
                </div>

                <div class="form-group">
                    <label for="quantity">Quantity:</label>
                    <input type="number" id="quantity" name="quantity" required>
                </div>

                <button type="submit" class="admin-btn">Add Equipment</button>
            </form>

            <!-- Equipment List -->
            <h3>Current Equipment List</h3>
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Quantity</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($_SESSION['equipment'] as $equipment): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($equipment['name']); ?></td>
                            <td><?php echo htmlspecialchars($equipment['quantity']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>
    </div>
</body>
</html>
