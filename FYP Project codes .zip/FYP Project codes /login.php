<?php
session_start();

// If user is already logged in, redirect to home page
if (isset($_SESSION['user'])) {
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Login Page</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        /* Login page styles */
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Roboto', sans-serif; background: #f2f2f2; display: flex; justify-content: center; align-items: center; height: 100vh; }
        .login-container { width: 800px; height: 400px; background-color: white; border-radius: 8px; box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1); display: flex; overflow: hidden; }
        .left-panel { flex: 1; padding: 40px; }
        .right-panel { flex: 1; background: linear-gradient(135deg, #ff416c, #ff4b2b); color: white; display: flex; justify-content: center; align-items: center; flex-direction: column; text-align: center; }
        .right-panel h2 { margin-bottom: 10px; font-family: 'Poppins', sans-serif; }
        .right-panel a { text-decoration: none; color: white; background-color: rgba(255, 255, 255, 0.2); padding: 10px 20px; border-radius: 5px; font-size: 16px; margin-top: 15px; }
        h2 { font-family: 'Poppins', sans-serif; font-size: 28px; margin-bottom: 20px; color: #0f3460; }
        label { display: block; margin-bottom: 8px; font-size: 14px; }
        input { width: 100%; padding: 12px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 50px; box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); font-size: 16px; }
        .login-btn { width: 100%; padding: 12px; background-color: #e94560; border: none; color: white; font-size: 18px; border-radius: 50px; cursor: pointer; transition: background-color 0.3s ease; }
        .login-btn:hover { background-color: #d1304b; }
        .remember-forgot { display: flex; justify-content: space-between; align-items: center; font-size: 14px; }
        .remember-forgot a { color: #e94560; text-decoration: none; }
        .social-login { display: flex; justify-content: flex-end; gap: 10px; margin-top: 10px; }
        .social-login a { background-color: #f2f2f2; padding: 10px; border-radius: 50%; font-size: 18px; color: #555; text-decoration: none; }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="left-panel">
            <h2>Sign In</h2>
            <form action="process_login.php" method="post">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" placeholder="Username" required>

                <label for="password">Password</label>
                <input type="password" id="password" name="password" placeholder="Password" required>

                <div class="remember-forgot">
                    <label><input type="checkbox" name="remember"> Remember Me</label>
                    <a href="#">Forgot Password</a>
                </div>

                <button type="submit" class="login-btn">Sign In</button>

                <div class="social-login">
                    <a href="#"><i class="fa fa-facebook"></i></a>
                    <a href="#"><i class="fa fa-twitter"></i></a>
                </div>
            </form>
        </div>

        <div class="right-panel">
            <h2>Welcome to login</h2>
            <p>Don't have an account?</p>
            <a href="signup.php">Sign Up</a>
        </div>
    </div>
</body>
</html>
